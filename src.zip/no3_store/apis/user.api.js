import axios from "axios";



export const userAllGetApi = async ()=>{
    try{
        const response = await axios.get("http://localhost:3001/user")
        return response.data
    }catch(error){
        return error

    }
}

export const userLoginApi = async (loginUser) => {
    try {
        const response = await axios.get(
            `http://localhost:3001/user?username=${loginUser.username}`
        );
        const users = response.data;

        if (users.length === 0) {
            throw new Error(
                "아이디 또는 비밀번호가 일치하지 않습니다."
            );
        }

        const foundUser = users[0];

        return foundUser;

    } catch (error) {
        throw error;
    }
};

export const userRegisterApi = async (userObj)=>{
    try{
        const response = await axios.get(`http://localhost:3001/user?username=${userObj.username}`)
        const users = response.data
        if(users.length>0){
            return Error("이미 존재하는 사용자입니다.")
        }

        return await axios.post(`http://localhost:3001/user`,userObj)
        
    }catch(error){
        return error
    }
}



